#include "CEffect.h"

CEffect::CEffect(CVector pos) : position_(pos), status_(0) {}