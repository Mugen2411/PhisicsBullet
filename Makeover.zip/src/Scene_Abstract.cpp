#include "Scene_Abstract.h"

Scene_Abstract::Scene_Abstract(SceneManager *scn_mng) : scene_manager_(scn_mng) {}

Scene_Abstract::~Scene_Abstract() {}
