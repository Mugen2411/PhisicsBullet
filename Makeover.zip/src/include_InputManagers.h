#pragma once

#include "CKeyInputManager.h"
#include "CSTGInputManager.h"